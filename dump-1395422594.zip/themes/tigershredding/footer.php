<?php get_template_part('partial/footer', 'contents'); ?>
<?php get_template_part('partial/acf', 'google-map'); ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/script.js"></script>
<?php wp_footer(); ?>
</body>
</html>