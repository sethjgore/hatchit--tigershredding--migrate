/**
 * Middleman tasks configuration
 */

'use strict';

var config = require('../config');

module.exports = {
  options: {
      useBundle: true
    },
  server: {}
}