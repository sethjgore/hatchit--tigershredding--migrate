/**
 * Middleman taks configuration
 */

'use strict';

var config = require('../config');

module.exports = {
  dev : {
    path: 'http://localhost:9999/clients/hatchit/tigershredding'
  }
}