<div class="blog__date" role="post-date">
  <div class="blog__date-box">
    <span class="d"><?php echo get_the_time('d'); ?></span>
    <span class="m"><?php echo get_the_time('M');?></span>
    <span class="y"><?php echo get_the_time('Y'); ?></span>
  </div>
</div>