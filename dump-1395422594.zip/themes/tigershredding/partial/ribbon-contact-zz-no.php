<div class="block__contact">
  <div class="contact__box">
    <div class="contact__row">
      <div class="contact__column">
        <p class="contact__message">CALL US TODAY!</p>
        <p class="contact__number">225.303.0125</p>
      </div>
    </div>
  </div>
</div>
