<nav id="navblog--simple" class="navigation" role="navigation">
  <div class="navblog__previous"><?php previous_post_link( '%link', 'Previous Post' ); ?></div>
  <div class="navblog__next"><?php next_post_link( '%link', 'Next Post' ); ?></div>
</nav>