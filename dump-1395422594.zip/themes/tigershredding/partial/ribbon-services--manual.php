<section class="is__background--c-main">
  <div class="block__services--ribbon">
    <div class="services--row" role="company-services">
      <div class="services--column">
        <ul>
          <a href="<?php bloginfo('url'); ?>/one-time-purge/"><li>one time <br> purge</li></a>
          <a href="<?php bloginfo('url'); ?>/residential-walk-ins/"><li>residential & <br> walk-ins</li></a>
        </ul>
      </div>
      <div class="services__logo-column">
        <div class="services__logo-box" role="company-logo">
          <div class="services__logo--image"></div>
        </div>
      </div>
      <div class="services--column">
        <ul>
          <a href="<?php bloginfo('url'); ?>/customized-plans/"><li>customized <br> plans</li></a>
           <a href="<?php bloginfo('url'); ?>/harddrive-destruction/"><li>hard drive <br> destruction</li></a>
        </ul>
      </div>
    </div>
  </div>
</section>