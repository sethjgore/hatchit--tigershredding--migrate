<div class="block__testmonial">
  <div class="testmonial__box">
    <div class="testmonial__row">
      <div class="testmonial__message">
        <blockquote class="testmonial__message--text">"Tiger Shredding was prompt, professional and provided great customer service throughout the process."</blockquote>
        <p class="testmonial__message--customer"> A valued customer </p>
      </div>
    </div>
  </div>
</div>