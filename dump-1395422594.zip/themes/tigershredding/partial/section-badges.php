<div class="block__badges zz_body zz_d">
  <div class="badges__box">
    <div class="badges__row">
      <div class="badges__items">
        <div class="badges__company--image badges__company--aaa">
        <!--<img src="<?php echo get_bloginfo('template_directory'); ?>/img/badges/aaa.png" alt="">-->
        <script language="JavaScript" type="text/javascript" src="http://www.naidonline.org/cgi-bin/naid-all/certverify/verify?Member=2940"></script>
        </div>
        <div class="badges__company--message">
          <p>
            “Our facilities have been certified by <br> the
  industry standard.” -Josh Goodson, Owner
          </p>
        </div>
      </div>
      <div class="badges__items">
        <div class="badges__company--image "><img class="aaa" src="<?php echo get_bloginfo('template_directory'); ?>/img/badges/geaux.png" alt=""></div>
        <div class="badges__company--message"></div>
      </div>
      <div class="badges__items">
        <div class="badges__company--image"><img src="<?php echo get_bloginfo('template_directory'); ?>/img/badges/hipaa.png" alt=""></div>
        <div class="badges__company--message">
          <p>
            Don’t Worry. <br> Your Privacy is our Highest Concern.
          </p>
        </div>
      </div>
    </div>
  </div>
</div>