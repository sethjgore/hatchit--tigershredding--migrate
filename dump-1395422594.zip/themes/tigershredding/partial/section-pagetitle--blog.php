 <div class="block__pagetitle">
   <div class="pagetitle__box">
    <div class="pagetitle__title">
      <h1 class="pagetitle__image"></h1>
    </div>
   </div>
 </div>